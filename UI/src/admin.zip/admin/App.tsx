import { useState, useEffect } from "react";
import { Sidebar } from "./components/Sidebar";
import { TopNav } from "./components/TopNav";
import { ContestOverview } from "./components/ContestOverview";
import { StatsPanel } from "./components/StatsPanel";
import { ProblemsView } from "./components/ProblemsView";
import { TeamsView } from "./components/TeamsView";
import { getActiveContest } from "./services/api";
import { ContestResponse } from "./types/api";
import { Toaster } from "./components/ui/sonner";

export default function AdminApp({ onLogout }: { onLogout: () => void }) {
  const [activeView, setActiveView] = useState("Overview");
  const [currentContest, setCurrentContest] = useState<ContestResponse | null>(null);

  useEffect(() => {
    if (activeView === "Overview") return;
    getActiveContest().then(setCurrentContest).catch(() => setCurrentContest(null));
  }, [activeView]);

  const renderView = () => {
    switch (activeView) {
      case "Overview":
        return (
          <>
            <ContestOverview />
            <StatsPanel />
          </>
        );
      case "Problems":
        return <ProblemsView contestId={currentContest?.id ?? null} />;
      case "Teams":
        return <TeamsView />;
      default:
        return <div>Pending</div>;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />

      <div className="flex-1 flex flex-col">
        <TopNav onLogout={onLogout} />

        <main className="flex-1 overflow-y-auto p-8">
          {renderView()}
        </main>
      </div>

      <Toaster />
    </div>
  );
}
