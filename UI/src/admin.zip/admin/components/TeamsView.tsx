import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { UserPlus } from 'lucide-react';
import { RegisterModal } from './RegisterModal';

export function TeamsView() {
  const [registerModalOpen, setRegisterModalOpen] = useState(false);

  return (
    <>
      <Card className="border border-gray-200 shadow-sm">
        <CardHeader className="bg-[#1E293B] text-white">
          <div className="flex items-center justify-between">
            <CardTitle>Teams</CardTitle>
            <Button 
              size="sm"
              className="gap-2"
              onClick={() => setRegisterModalOpen(true)}
            >
              <UserPlus className="w-4 h-4" />
              Register Team / User
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <p className="text-slate-600 py-8 text-center">
            Teams list - Backend integration pending (no endpoint to list teams)
          </p>
        </CardContent>
      </Card>

      <RegisterModal 
        open={registerModalOpen}
        onOpenChange={setRegisterModalOpen}
      />
    </>
  );
}
