import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ToggleGroup, ToggleGroupItem } from './ui/toggle-group';
import { Play, Pause, StopCircle, Plus, Calendar, Clock, FileText } from 'lucide-react';
import { 
  getActiveContest, 
  getUpcomingContest, 
  startContest, 
  pauseContest, 
  endContest 
} from '../services/api';
import { ContestResponse } from '../types/api';
import { CreateContestModal } from './CreateContestModal';
import { 
  AlertDialog, 
  AlertDialogAction, 
  AlertDialogCancel, 
  AlertDialogContent, 
  AlertDialogDescription, 
  AlertDialogFooter, 
  AlertDialogHeader, 
  AlertDialogTitle 
} from './ui/alert-dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from './ui/tooltip';
import { toast } from 'sonner';

export function ContestOverview() {
  const [contestType, setContestType] = useState<'active' | 'upcoming'>('active');
  const [contest, setContest] = useState<ContestResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [endDialogOpen, setEndDialogOpen] = useState(false);

  const loadContest = async () => {
    setLoading(true);
    try {
      const data = contestType === 'active' 
        ? await getActiveContest() 
        : await getUpcomingContest();
      setContest(data);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to load contest');
      setContest(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContest();
  }, [contestType]);

  const handleStart = async () => {
    if (!contest) return;
    try {
      await startContest(contest.id);
      toast.success('Contest started');
      await loadContest();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to start contest');
    }
  };

  const handlePause = async () => {
    if (!contest) return;
    try {
      await pauseContest(contest.id);
      toast.success('Contest paused');
      await loadContest();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to pause contest');
    }
  };

  const handleEnd = async () => {
    if (!contest) return;
    try {
      await endContest(contest.id);
      toast.success('Contest ended');
      setEndDialogOpen(false);
      await loadContest();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to end contest');
    }
  };

  const getStatusColor = (status: ContestResponse['status']) => {
    switch (status) {
      case 'RUNNING':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'PAUSED':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'ENDED':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'UPCOMING':
        return 'bg-blue-100 text-blue-700 border-blue-200';
    }
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours === 0) return `${mins} minutes`;
    if (mins === 0) return `${hours} hour${hours > 1 ? 's' : ''}`;
    return `${hours} hour${hours > 1 ? 's' : ''} ${mins} min`;
  };

  const formatStartTime = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      timeZoneName: 'short',
    });
  };

  const canStart = contest?.status === 'UPCOMING';
  const canPause = contest?.status === 'RUNNING';
  const canEnd = contest?.status === 'RUNNING' || contest?.status === 'PAUSED';

  return (
    <>
      <Card className="border border-gray-200 shadow-sm">
        <CardHeader className="bg-[#1E293B] text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <CardTitle>Contest Overview</CardTitle>
              <ToggleGroup 
                type="single" 
                value={contestType} 
                onValueChange={(value) => value && setContestType(value as 'active' | 'upcoming')}
                className="bg-slate-700 rounded-lg p-1"
              >
                <ToggleGroupItem 
                  value="active" 
                  className="data-[state=on]:bg-white data-[state=on]:text-slate-900"
                >
                  Active
                </ToggleGroupItem>
                <ToggleGroupItem 
                  value="upcoming" 
                  className="data-[state=on]:bg-white data-[state=on]:text-slate-900"
                >
                  Upcoming
                </ToggleGroupItem>
              </ToggleGroup>
            </div>
            {contest && (
              <Badge className={`${getStatusColor(contest.status)} border`}>
                {contest.status}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {loading ? (
            <div className="text-slate-600 py-8 text-center">Loading contest...</div>
          ) : !contest ? (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="text-slate-600 mb-6 text-center">No contest found</div>
              <Button 
                className="bg-[#1E293B] hover:bg-[#334155] gap-2"
                onClick={() => setCreateModalOpen(true)}
              >
                <Plus className="w-4 h-4" />
                Create Contest
              </Button>
            </div>
          ) : (
            <>
              {/* Contest Details Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-slate-600 mb-1 flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Contest Name
                    </label>
                    <p className="text-slate-900">{contest.title}</p>
                  </div>
                  <div>
                    <label className="text-slate-600 mb-1 flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Description
                    </label>
                    <p className="text-slate-900">{contest.description}</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="text-slate-600 mb-1 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Start Time
                    </label>
                    <p className="text-slate-900">{formatStartTime(contest.startTime)}</p>
                  </div>
                  <div>
                    <label className="text-slate-600 mb-1 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Duration
                    </label>
                    <p className="text-slate-900">{formatDuration(contest.durationMinutes)}</p>
                  </div>
                </div>
              </div>

              {/* Control Buttons */}
              <div className="border-t border-gray-200 pt-6">
                <h3 className="mb-4 text-slate-700">Contest Controls</h3>
                <div className="flex flex-wrap gap-3 mb-6">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div>
                          <Button 
                            className="bg-green-600 hover:bg-green-700 gap-2"
                            onClick={handleStart}
                            disabled={!canStart}
                          >
                            <Play className="w-4 h-4" />
                            Start Contest
                          </Button>
                        </div>
                      </TooltipTrigger>
                      {!canStart && (
                        <TooltipContent>
                          <p>Only available when status is UPCOMING</p>
                        </TooltipContent>
                      )}
                    </Tooltip>
                  </TooltipProvider>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div>
                          <Button 
                            className="bg-orange-600 hover:bg-orange-700 gap-2"
                            onClick={handlePause}
                            disabled={!canPause}
                          >
                            <Pause className="w-4 h-4" />
                            Pause Contest
                          </Button>
                        </div>
                      </TooltipTrigger>
                      {!canPause && (
                        <TooltipContent>
                          <p>Only available when status is RUNNING</p>
                        </TooltipContent>
                      )}
                    </Tooltip>
                  </TooltipProvider>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div>
                          <Button 
                            className="bg-red-600 hover:bg-red-700 gap-2"
                            onClick={() => setEndDialogOpen(true)}
                            disabled={!canEnd}
                          >
                            <StopCircle className="w-4 h-4" />
                            End Contest
                          </Button>
                        </div>
                      </TooltipTrigger>
                      {!canEnd && (
                        <TooltipContent>
                          <p>Only available when status is RUNNING or PAUSED</p>
                        </TooltipContent>
                      )}
                    </Tooltip>
                  </TooltipProvider>
                </div>

                {/* Create Contest Button */}
                <Button 
                  className="bg-[#1E293B] hover:bg-[#334155] gap-2"
                  onClick={() => setCreateModalOpen(true)}
                >
                  <Plus className="w-4 h-4" />
                  Create Contest
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Create Contest Modal */}
      <CreateContestModal 
        open={createModalOpen}
        onOpenChange={setCreateModalOpen}
        onSuccess={loadContest}
      />

      {/* End Contest Confirmation Dialog */}
      <AlertDialog open={endDialogOpen} onOpenChange={setEndDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>End Contest?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to end this contest? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleEnd} className="bg-red-600 hover:bg-red-700">
              End Contest
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
