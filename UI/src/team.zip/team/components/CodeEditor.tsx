import { useEffect, useState } from "react";
import { Button } from "./ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Send } from "lucide-react";
import { submitCode } from "../services/teamApi";

type Props = {
  contestId: number;
  problem: { id: number; title: string } | null;
};

export function CodeEditor({ contestId, problem }: Props) {
  const [language, setLanguage] = useState("cpp");
  const [code, setCode] = useState("");

  useEffect(() => {
    if (!problem) return;

    setCode(`#include <iostream>
using namespace std;

int main() {
    // Your solution for ${problem.title}
    
    return 0;
}`);
  }, [problem]);

  if (!problem) {
    return (
      <div className="flex flex-1 items-center justify-center text-gray-500">
        Select a problem
      </div>
    );
  }

  const handleSubmit = async () => {
    await submitCode({
      contestId,
      problemId: problem.id,
      language,
      code,
    });
    alert("Submitted");
  };

  return (
    <div className="flex flex-col flex-1 bg-white rounded-lg border border-gray-200 shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
        <h3 className="text-gray-900">{problem.title}</h3>

        <div className="flex items-center gap-3">
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="cpp">C++17</SelectItem>
              <SelectItem value="java">Java 11</SelectItem>
              <SelectItem value="python">Python 3</SelectItem>
              <SelectItem value="c">C11</SelectItem>
            </SelectContent>
          </Select>

          <Button
            onClick={handleSubmit}
            className="bg-[#FACC15] hover:bg-[#F4C000] text-gray-900"
          >
            <Send className="w-4 h-4 mr-2" />
            Submit
          </Button>
        </div>
      </div>

      {/* Editor — FIXED */}
      <div className="flex flex-1 p-0">
        <Textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="flex-1 w-full font-mono resize-none border-0 rounded-none focus-visible:ring-0"
          placeholder="Write your code here..."
        />
      </div>
    </div>
  );
}
