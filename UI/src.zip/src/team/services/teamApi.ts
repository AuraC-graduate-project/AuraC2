import { apiJson } from "../../services/http";

const API_BASE = (import.meta as any).env?.VITE_API_BASE_URL ?? "";

/* ===================== TYPES ===================== */

export type ContestResponse = {
    id: number;
    title: string;
    description: string;
    durationMinutes: number;
    status: string;
    startTime: string;
};

export type ProblemResponse = {
    id: number;
    title: string;
    description: string;
    timeLimit: number;
    memoryLimit: number;
    difficulty: string;
    contestId: number;
};

export type SubmissionRequest = {
    contestId: number;
    problemId: number;
    language: string;
    code: string;
};

export type SubmissionResponse = {
    id: number;
    contestId: number;
    problemId: number;
    verdict: string;
    createdAt: string;
    executionTime: number | null;
    memoryUsage: number | null;
};

/* ===================== CONTEST ===================== */

export function getActiveContest() {
    return apiJson<ContestResponse>(`${API_BASE}/api/contest/active`);
}

/* ===================== PROBLEMS ===================== */

export function getProblemsByContest(contestId: number) {
    return apiJson<ProblemResponse[]>(
        `${API_BASE}/api/problems/contest/${contestId}`
    );
}

/* ===================== SUBMISSIONS ===================== ✅ THIS WAS MISSING */

export function submitCode(body: SubmissionRequest) {
    return apiJson<SubmissionResponse>(`${API_BASE}/api/submissions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
    });
}

export function getMySubmissions() {
    return apiJson<SubmissionResponse[]>(
        `${API_BASE}/api/submissions/getAll`
    );
}
