import React, { useEffect, useState } from "react";
import { Header } from "./components/Header";
import { ProblemSidebar } from "./components/ProblemSidebar";
import { CodeEditor } from "./components/CodeEditor";
import { getActiveContest, getProblemsByContest } from "./services/teamApi";

export default function TeamApp({ onLogout }: { onLogout: () => void }) {
  const [contest, setContest] = useState<any | null>(null);
  const [problems, setProblems] = useState<any[]>([]);
  const [selectedProblem, setSelectedProblem] = useState<any | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let mounted = true;

    (async () => {
      try {
        const c = await getActiveContest();

        if (!mounted) return;

        // ✅ Always set contest (even if null)
        setContest(c ?? null);

        // 🚫 No active contest → STOP
        if (!c) {
          setProblems([]);
          setSelectedProblem(null);
          setLoaded(true);
          return;
        }

        const p = await getProblemsByContest(c.id);
        if (!mounted) return;

        setProblems(p);
        setSelectedProblem(p[0] ?? null);
        setLoaded(true);

      } catch (e) {
        console.error("Failed to load team page:", e);
        setLoaded(true);
      }
    })();

    return () => {
      mounted = false;
    };
  }, []);

  if (!loaded) return <div className="p-6">Loading…</div>;

  const endTime =
    contest
      ? new Date(
        new Date(contest.startTime).getTime() +
        contest.durationMinutes * 60_000
      ).toISOString()
      : undefined;

  return (
    <div className="flex flex-col min-h-screen">
      <Header
        contestName={contest?.title}
        contestEndTime={endTime}
        teamName="Code Warriors"
        onLogout={onLogout}
      />

      <div className="flex flex-1">
        <ProblemSidebar
          problems={problems}
          selectedProblem={selectedProblem}
          onSelectProblem={setSelectedProblem}
        />

        <CodeEditor
          contestId={contest?.id}
          problem={selectedProblem}
        />
      </div>
    </div>
  );
}
