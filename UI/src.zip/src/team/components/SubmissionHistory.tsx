import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { CheckCircle2, XCircle, Clock } from 'lucide-react';

interface Submission {
  id: number;
  problem: string;
  verdict: 'Accepted' | 'Wrong Answer' | 'Time Limit Exceeded' | 'Pending';
  time: string;
  executionTime: string;
}

const submissions: Submission[] = [
  { id: 1, problem: 'A', verdict: 'Accepted', time: '10:23:45', executionTime: '0.12s' },
  { id: 2, problem: 'B', verdict: 'Accepted', time: '10:45:12', executionTime: '0.08s' },
  { id: 3, problem: 'C', verdict: 'Wrong Answer', time: '11:02:33', executionTime: '0.15s' },
  { id: 4, problem: 'C', verdict: 'Wrong Answer', time: '11:15:20', executionTime: '0.14s' },
  { id: 5, problem: 'D', verdict: 'Time Limit Exceeded', time: '11:45:50', executionTime: '2.00s' },
];

export function SubmissionHistory() {
  const getVerdictIcon = (verdict: Submission['verdict']) => {
    switch (verdict) {
      case 'Accepted':
        return <CheckCircle2 className="w-4 h-4 text-green-600" />;
      case 'Pending':
        return <Clock className="w-4 h-4 text-yellow-600" />;
      default:
        return <XCircle className="w-4 h-4 text-red-600" />;
    }
  };

  const getVerdictColor = (verdict: Submission['verdict']) => {
    switch (verdict) {
      case 'Accepted':
        return 'text-green-600';
      case 'Pending':
        return 'text-yellow-600';
      default:
        return 'text-red-600';
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200 bg-gray-50">
        <h3 className="text-gray-900">Submission History</h3>
      </div>
      <div className="overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Problem</TableHead>
              <TableHead>Verdict</TableHead>
              <TableHead>Time</TableHead>
              <TableHead>Execution Time</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {submissions.map((submission) => (
              <TableRow key={submission.id}>
                <TableCell>
                  <span className="px-2 py-1 bg-gray-100 rounded">
                    {submission.problem}
                  </span>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {getVerdictIcon(submission.verdict)}
                    <span className={getVerdictColor(submission.verdict)}>
                      {submission.verdict}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="text-gray-600">{submission.time}</TableCell>
                <TableCell className="text-gray-600">{submission.executionTime}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}