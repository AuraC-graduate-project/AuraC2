import React from "react";

type Problem = {
  id: number;
  title: string;
};

export function ProblemSidebar({
  problems,
  selectedProblem,
  onSelectProblem,
}: {
  problems: Problem[];
  selectedProblem: Problem | null;
  onSelectProblem: (p: Problem) => void;
}) {
  return (
    <aside className="w-64 bg-white border-r border-gray-200">
      <div className="p-4 border-b">
        <h2 className="text-gray-900">Problems</h2>
      </div>

      <div className="p-3 space-y-2">
        {problems.map((p, idx) => (
          <button
            key={p.id}
            onClick={() => onSelectProblem(p)}
            className={`w-full p-3 rounded-lg border text-left ${selectedProblem?.id === p.id
                ? "ring-2 ring-[#FACC15] bg-yellow-50"
                : "hover:bg-gray-50"
              }`}
          >
            <div className="font-semibold">
              {String.fromCharCode(65 + idx)}
            </div>
            <div className="text-sm text-gray-600">{p.title}</div>
          </button>
        ))}
      </div>
    </aside>
  );
}
