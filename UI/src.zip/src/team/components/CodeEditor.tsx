import { useState } from "react";
import { submitCode } from "../services/teamApi";
import { Button } from "./ui/button";

type Props = {
  contestId: number;
  problem: { id: number; title: string } | null;
};

export function CodeEditor({ contestId, problem }: Props) {
  const [language, setLanguage] = useState("cpp");
  const [code, setCode] = useState("");

  if (!problem) return <div>Select a problem</div>;

  const handleSubmit = async () => {
    await submitCode({
      contestId,
      problemId: problem.id,
      language,
      code,
    });
    alert("Submitted");
  };

  return (
    <div className="flex flex-col flex-1 bg-white border rounded">
      <div className="p-4 border-b flex justify-between">
        <h3>{problem.title}</h3>
        <Button onClick={handleSubmit}>Submit</Button>
      </div>

      <textarea
        className="flex-1 p-4 font-mono"
        value={code}
        onChange={(e) => setCode(e.target.value)}
      />
    </div>
  );
}
